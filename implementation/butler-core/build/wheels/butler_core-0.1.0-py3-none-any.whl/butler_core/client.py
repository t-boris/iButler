"""Python client for the core socket. Butler tools use it to submit operations."""
from __future__ import annotations

import json
import os
import socket
import uuid
from pathlib import Path

STATE = Path(os.environ.get("BUTLER_CORE_STATE", Path.home() / ".local/share/butler-core"))
SOCKET = Path(os.environ.get("BUTLER_CORE_SOCKET", STATE / "core.sock"))


class CoreUnavailable(ConnectionError):
    """The daemon is not reachable; nothing was submitted."""


class CoreError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(f"{code}: {message}")
        self.code, self.message = code, message


class Client:
    def __init__(self, path=None, timeout=15.0):
        self.path, self.timeout = Path(path or SOCKET), timeout

    def call(self, method, _socket_timeout=None, **params):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(_socket_timeout or self.timeout)
        try:
            try:
                sock.connect(str(self.path))
            except (FileNotFoundError, ConnectionRefusedError) as error:
                raise CoreUnavailable(f"core daemon unreachable: {type(error).__name__}") from None
            request = {"id": uuid.uuid4().hex[:8], "method": method, "params": params}
            sock.sendall((json.dumps(request, ensure_ascii=False) + "\n").encode())
            stream = sock.makefile("rb")
            line = stream.readline()
        finally:
            sock.close()
        if not line:
            raise CoreError("no_response", "connection closed without a response")
        response = json.loads(line)
        if not response.get("ok"):
            error = response.get("error") or {}
            raise CoreError(error.get("code", "error"), error.get("message", ""))
        return response["result"]

    def execute(self, kind, persona, target, params, idempotency_key, principal=None, timeout=60, task=None):
        request = {"kind": kind, "persona": persona, "target": target, "params": params,
                   "idempotency_key": idempotency_key, "principal": principal, "task": task}
        return self.call("execute", _socket_timeout=timeout + 10, request=request, timeout=timeout)

    def available(self):
        try:
            self.call("ping", _socket_timeout=2)
            return True
        except (CoreUnavailable, CoreError, OSError):
            return False
